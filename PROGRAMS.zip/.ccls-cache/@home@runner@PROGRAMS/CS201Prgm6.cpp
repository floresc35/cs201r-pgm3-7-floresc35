// CS201R-PGM7.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "Functions.h"
#include "Media.h"

using namespace std;

int main() {

    ifstream inList, inCommands;
    ofstream outFile, outErr;

    try {
        inList.exceptions(ifstream::failbit);
        inList.open("mediaList.txt");
        inCommands.exceptions(ifstream::failbit);
        inCommands.open("mediaCommands.txt");
        outFile.exceptions(ofstream::failbit);
        outFile.open("mediaReport.txt");
        outErr.exceptions(ofstream::failbit);
        outErr.open("mediaError.txt");
    }
    catch (ifstream::failure& fail) {
        cout << "Could not open input file" << endl;
        cout << fail.what() << endl;
        cout << fail.code() << endl;
        exit(1);
    }

    vector <Media*> myLib;

    // read data into myLib
    readMediaList(inList, outErr, myLib);
    inList.close();


    // prepare to read the commands
    string commandRecord;
    while (getline(inCommands, commandRecord)) {
        char choice = commandRecord[0];

        if (choice == 'Q') {
            cout << "Thank You for Using Media Everywhere" << endl;
            break;
        }
        else if (choice == 'A' || choice == 'M' || choice == 'B' || choice == 'S') {
            if (commandRecord.find(',') == string::npos) {
                //comand has only type, call function for type
                printReport(commandRecord, outFile, outErr, myLib);
            } else if (commandRecord.length() > 2 && commandRecord[1] == ',') {
                //command has type and genre, call function for genre
                printReportGenre(commandRecord, outFile, outErr, myLib);
            } else {
                //command length of 2 so call function for rating
                int rating = stoi(commandRecord.substr(2));
                if (isDigits(to_string(rating)) && rating >= 1 && rating <= 10) {
                    printReportRating(commandRecord, outFile, outErr, myLib);
                } else {
                    outErr << "ERROR: " << commandRecord << endl;
                    outErr << "There was an invalid value entered for rating." << endl;
                }
            }
        }
        else if (choice == 'T') {
            printTotals(outFile, myLib);
        }
        else if (choice == 'N') {
            addContent(commandRecord, outFile, outErr, myLib);
        }
        else {
            cout << "There is an error in the input command: " << commandRecord << "\n";
        }
    }

    inCommands.close();
    outFile.close();
    outErr.close();

    //clean up memory
    for (auto media : myLib) {
        delete media;
    }
}